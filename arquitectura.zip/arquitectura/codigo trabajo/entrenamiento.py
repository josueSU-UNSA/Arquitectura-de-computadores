#entrenamos el modo
import cv2 
import os 
import numpy as np#operaciones matriciales o vectoriales
#---- Importamos las fotos tomadas anteriormente--- 
direccion = r'C:\Users\josue\Desktop\arquitectura\fotos proyecto\Tapabocas' 
lista = os.listdir (direccion)#importar las fotos como un vector
etiquetas = [] #almacenamos las etiquetas, la forma en que el computador almacena la info
#ejm si tienes puesto el tapabocas eres 1  y sin esta un 0 
rostros = []
con = 0#contador
for nameDir in lista:#leemos las fotos
    nombre = direccion + '/' + nameDir#Leeremos las fotos tomadas de los rostros

    for fileName in os.listdir (nombre):#Asignaremos las etiquetas a cada foto
        #son las fotos anteriormentetomadas

        etiquetas.append (con) #Valor de la etiqueta ( asignamos O a la primera etiqueta y la la segunda) 
        rostros.append (cv2.imread (nombre + '/' + fileName, 0)) #Añadimos las imagenes en EDG 
                                                                 #juntamos las fotos con las etiquetas
        
        #print ('Rostros: ', nameDir + '/' + fileName) #Sin tapabocas es o con Tapabocas es i
    con = con + 1
#- Creamos el modelo 
reconocimiento = cv2.face.LBPHFaceRecognizer_create()

#Empezamos a entrenarlo con las fotos 
reconocimiento.train(rostros, np.array(etiquetas))#se pasa el array de rostros

#Guardamos el modelo 
reconocimiento.write('modeloLBP.xml') 
print ("Modelo Creado")
