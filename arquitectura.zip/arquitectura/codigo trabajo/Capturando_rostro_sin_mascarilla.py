import cv2
from matplotlib import pyplot#trabaja junto a mtcnn
import os#nos ayuda con el manejo de carpetas y directorios
import imutils#cambio de tamaños en imagenes
from mtcnn.mtcnn import MTCNN#descriptor y detector del rostro

# creacion de la carpeta donde almacenara el entrenamieto
direccion = r'C:\Users\josue\Desktop\arquitectura\fotos proyecto\Tapabocas'
nombre = r'Sin_tapabocas'
carpeta = direccion + '/' + nombre

# creamos la carpeta 
if not os.path.exists (carpeta):#se crea la carpeta, sin en caso no esta creada
    print("Carpeta creada "+carpeta)
    os.makedirs (carpeta)

#capturamos el video en tiempo real
detector = MTCNN()#el detector es igual a la red neuronal convolucional
cap = cv2.VideoCapture(0)#toma la camara
count = 0#contador nos ayudara a la cantidad de fotos a tomar

while True:
    ret, frame = cap.read() #se ejecuta en un while para que vea cada frame
    gris = cv2.cvtColor (frame, cv2.COLOR_BGR2GRAY)#pasamos a escala de grices 
    copia = frame.copy()#copiaremos una copia de la captura en tiempo real esto 
                        #para pasar al detector

    caras = detector.detect_faces (copia)#le damos la copia creada
    for i in range (len(caras)):#lectura de los rostros detectados
        x1, y1, ancho, alto = caras[i]['box']#coordenadas de esquina superior izquierda
                                            #el ancho y alto nos tomara solo
                                            #los pixeles del rostro
                                            #box es una cajita de pixeles del rostro
        x2, y2 = x1 + ancho, y1 + alto #coordenadas de esquina inferior derecha
        
        cara_reg = frame [y1:y2, x1:x2] #cara registra sera el fotograma de las coordenas
                                        #anteriormente mencionada
        cara_reg = cv2.resize (cara_reg, (150, 200), interpolation = cv2.INTER_CUBIC)
                    #ajustaremos tamaño para tener todas las fotos del mismo tamaño
                    #se almacena en 150 X 200
                    #le hacemos una interpolacion cubica
        cv2.imwrite(carpeta +"/rostro_{}.jpg". format (count), cara_reg)
                    #almacenamos esas fotos enumeradas 
        count = count + 1
    cv2.imshow("Entrenamiento", frame)#mostraremos el video en tiempo real
    t = cv2.waitKey(1) #almacenara valor por teclado
    if t == 27 or count >= 50:  # salida para esc o llegue al limite de fotos
        break
cap.release() #cerramos ventana
cv2.destroyAllWindows()#destruimos todo

